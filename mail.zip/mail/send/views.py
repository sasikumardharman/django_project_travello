from django.shortcuts import render
from django.http import HttpResponse
import smtplib 

# Create your views here.
def mailsent(request):
    return render(request,'sentmail.html')

def sended(request):
    sender= (request.POST['mailid'])

    emessage= (request.POST['mess'])
    try:
        s = smtplib.SMTP('smtp.gmail.com', 587) 
    
        # start TLS for security 
        s.starttls() 
    
        # Authentication 
        s.login("sasikumard54@gmail.com", "9442822853") 
    
        # message to be sent 
        message = 'Subject: {}\n\n{}'.format('hi this is test mail from django', emessage)
    
        # sending the mail 
        s.sendmail("sasikumard54@gmail.com", sender, message) 
    
        # terminating the session 
        return render(request, "sentmail.html",{'mailsented': "mail is sended successfully"})
    
    except smtplib.SMTPException :
        
        return render(request, "sentmail.html",{'mailsented': "unable to sent mail"})