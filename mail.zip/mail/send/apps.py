from django.apps import AppConfig


class SendConfig(AppConfig):
    name = 'send'
