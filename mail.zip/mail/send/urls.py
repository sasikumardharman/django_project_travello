from django.urls import path

from . import views

urlpatterns = [
    path('', views.mailsent, name = 'mailsent'),
    path('sended', views.sended, name= 'sended')
]