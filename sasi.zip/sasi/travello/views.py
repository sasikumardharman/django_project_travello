from django.shortcuts import render
from django.http import HttpResponse
from .models import Destination, Team
import smtplib 
# Create your views here.
def index(request):
    dests= Destination.objects.all()

    return render(request, 'index.html',{'dests' : dests})

def destinations(request):
    dests= Destination.objects.all()

    return render(request, 'destinations.html',{'dests' : dests})

def about(request):
    teams= Team.objects.all()

    return render(request, 'about.html',{'teams' : teams})

def sended(request):
    sender= (request.POST['mailid'])

    name= (request.POST['name'])
    try:
        s = smtplib.SMTP('smtp.gmail.com', 587) 
    
        # start TLS for security 
        s.starttls() 
    
        # Authentication 
        s.login("sasikumard54@gmail.com", "9442822853") 
    
        # message to be sent 
        message = 'Subject: "Travello"\n\n"hi"{}"welcome to our travello group thank you for subscription, we will update all our activities in feauture mails."'.format(name)
    
        # sending the mail 
        s.sendmail("sasikumard54@gmail.com", sender, message) 
    
        # terminating the session 
        return render(request, "index.html")
    
    except smtplib.SMTPException :
        
        return render(request, "index.html")

